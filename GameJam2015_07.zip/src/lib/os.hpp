﻿#pragma once

//
// OS依存実装
//

#include "os_osx.hpp"
#include "os_win.hpp"
